<?php

 #Funciones
 require_once("funciones.inc.php"); 

//Configuración de variables globales para el sistema.

//Servidor local: 
define('CONFIG_DATABASE_HOST','localhost');
define('CONFIG_DATABASE_USER','rommy_epis');
define('CONFIG_DATABASE_PASS','Q6K5qsjcKhCi55k1');
define('CONFIG_DATABASE_NAME','puertas_abiertas');

//Servidor de desarrollo: 
//define('CONFIG_DATABASE_HOST','172.16.8.86');
//define('CONFIG_DATABASE_USER','UsrGalVirtualPEM');
//define('CONFIG_DATABASE_PASS','@Gal.VirtPEM#1');
//define('CONFIG_DATABASE_NAME','BDGaleriaVirtPEM');

//Servidor de producción: 
//define('CONFIG_DATABASE_HOST','172.16.8.236');
//define('CONFIG_DATABASE_USER','UsrGalVirtualPEM');
//define('CONFIG_DATABASE_PASS','@Gal.VirtPEM#1');
//define('CONFIG_DATABASE_NAME','BDGaleriaVirtPEM');


define('CONFIG_PATH_DATOS','datos/');
define('CONFIG_MODO_DEPURACION',true);

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

define('CONFIG_PATH_LIB','lib/');
define('CONFIG_PATH_INC_PUBLIC','inc/public/');
define('CONFIG_PATH_TPL_PUBLIC','tpl/public/');
define('CONFIG_PATH_INC_ADMIN','inc/admin/');
define('CONFIG_PATH_TPL_ADMIN','tpl/admin/');



//Conexión con la base de datos.

class BaseDatos//Clase para manejo de conexión con la base de datos
{
		protected $conexion;
		protected $db;
	 
		//Conectar DB
		public function conectar()
		{
			$this->conexion = mysqli_connect(CONFIG_DATABASE_HOST, CONFIG_DATABASE_USER, CONFIG_DATABASE_PASS, CONFIG_DATABASE_NAME);
			if ($this->conexion == 0) DIE("Lo sentimos, no se ha podido conectar con MySQL: " . mysqli_connect_error());
			$this->db = mysqli_select_db($this->conexion, CONFIG_DATABASE_NAME);
			$this->conexion->set_charset("utf8");
			if ($this->db == 0) DIE("Lo sentimos, no se ha podido conectar con la base datos: " . CONFIG_DATABASE_NAME);
	 
			return true;
	 
		}
		//Conectar DB
	 
		//Desconectar DB
		public function desconectar()
		{
			$this->conexion = null;
			$query = null;
	
		}
		//Desconectar DB
	 
		
		//Cuenta registros existentes de una determinada tabla
		public function cuentaregistros($tabla, $tipo)
		{
			
			$query = mysqli_query($this->conexion, "SELECT * FROM $tabla WHERE 1;");
			
			if ($query == 0) 
				if($tipo == "1"){
				    echo "<div class='alert alert-danger'>Sentencia incorrecta en la funci&oacute;n cuentaregistros, en el llamado a la tabla: $tabla.<br></div>";
				}else{
					return false;
				}
			else {
				$nregistrostotal = mysqli_num_rows($query);
				if($tipo == "1"){
					echo "<div class='alert alert-success'>Hay $nregistrostotal registros en la tabla: $tabla.<br></div>";
				}else{
					return mysqli_num_rows($query);
				}
				mysqli_free_result($query);
			}
		}
		//Cuenta registros existentes de una determinada tabla
		
		
		//Consulta los registros de una determinada tabla, segun la sentencia
		public function consultaregistros($select, $tabla, $where, $tipo)   
		{
	     
		//echo "SELECT $select FROM $tabla WHERE $where;";           
			
			$query = mysqli_query( $this->conexion, "SELECT $select FROM $tabla WHERE $where;");
			
			if ($query == 0) 
				if($tipo == "1"){
				    echo "<div class='alert alert-danger'>Sentencia incorrecta en la funci&oacute;n consultatodosregistros, en el llamado a la tabla: $tabla.<br></div>";
				}else{
					return false;
				}
			else {
				if($tipo == "1"){
					$numfilas = mysqli_num_rows($query);
				
					echo "<table class='table'>";
					echo "<tr>";
					
					for($i = 0; $i < $numfilas; $i++){
						
							$finfo  = mysqli_fetch_field_direct($query, $i);
							echo '<td><strong>' . $finfo->name . "</strong></td>";
		
					}
					
					echo "</tr>";
					
					while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)){ 
						echo "<tr>";
						for($i = 0; $i < $numfilas; $i++){
	
							$finfo  = mysqli_fetch_field_direct($query, $i);
							echo '<td>' .$row[$finfo->name] . "</td>";
							
						}
						echo "</tr>";  
						   
					} 
					
					echo "</table>";
	
				}else{
						$numcolumnas = mysqli_num_fields($query);
						
						$contador = 0;
						while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)){ 
							for($i = 0; $i < $numcolumnas; $i++){
								$finfo  = mysqli_fetch_field_direct($query, $i);
								$array_retornado[$contador][$i] = $row[$finfo->name];
							} 
							$contador = $contador+1; 
						} 
	
						return $array_retornado;
						
				}
				mysqli_free_result($query);
			}
		}
		//Consulta todos los registros de una determinada tabla
	
		
		//Edita registros existentes de una determinada tabla
		public function editaregistros($tabla, $sentencia, $where, $tipo)
		{
			
			//echo "UPDATE $tabla SET $sentencia WHERE $where;";
			
			$query = mysqli_query( $this->conexion, "UPDATE $tabla SET $sentencia WHERE $where;");
			if ($query == 0) 
				if($tipo == "1"){
				    echo "<div class='alert alert-danger'>Sentencia incorrecta en la funci&oacute;n editaregistros, en la edici&oacute;n a la tabla: $tabla.<br></div>";
				}else{
					return false;
				}
			else {
				//$nregistrostotal = mysqli_num_rows($query);
				if($tipo == "1"){
					echo "<div class='alert alert-success'>Sentencia correctamente ejecutada en la funci&oacute;n editaregistros, en la edici&oacute;n a la tabla: $tabla.<br></div>";
				}else{
					return true;
				}
				mysqli_free_result($query);
			}
		}
		//Edita registros existentes de una determinada tabla
		
		//Inserta registros en una determinada tabla
		public function insertaregistros($tabla, $campos, $datos, $tipo)
		{
			
		//echo "INSERT INTO $tabla ($campos) VALUES ($datos);";          
			
			$query = mysqli_query($this->conexion, "INSERT INTO $tabla ($campos) VALUES ($datos);");
			if ($query == 0) 
				if($tipo == "1"){
				    echo "<div class='alert alert-danger'>Sentencia incorrecta en la funci&oacute;n insertaregistros, en la inserci&oacute;n a la tabla: $tabla.<br></div>";
				}else{
					return false;
				}
			else {
				//$nregistrostotal = mysqli_num_rows($query);
				if($tipo == "1"){
					echo "<div class='alert alert-success'>Sentencia correctamente ejecutada en la funci&oacute;n insertaregistros, en la inserci&oacute;n a la tabla: $tabla.<br></div>";
				}else{
					return true;
				}
				mysqli_free_result($query);
			}
		}
		//Inserta registros en una determinada tabla
		
		
		//Eliminar registros en una determinada tabla
		public function eliminarregistros($tabla, $where, $tipo)
		{
			
			//echo "DELETE FROM $tabla WHERE $where;";
			
			$query = mysqli_query($this->conexion, "DELETE FROM $tabla WHERE $where;");
			if ($query == 0) 
				if($tipo == "1"){
				    echo "<div class='alert alert-danger'>Sentencia incorrecta en la funci&oacute;n eliminarregistros, en la eliminaci&oacute;n en la tabla: $tabla.<br></div>";
				}else{
					return false;
				}
			else {
				//$nregistrostotal = mysqli_num_rows($query);
				if($tipo == "1"){
					echo "<div class='alert alert-success'>Sentencia correctamente ejecutada en la funci&oacute;n eliminarregistros, en la eliminaci&oacute;n en la tabla: $tabla.<br></div>";
				}else{
					return true;
				}
				mysqli_free_result($query);
			}
		}
		//Eliminar registros en una determinada tabla	
		
}




?>
