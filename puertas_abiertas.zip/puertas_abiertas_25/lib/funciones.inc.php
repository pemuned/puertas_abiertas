<?php
//IMPRIMIR DATO EN PANTALLA CON TABULACION
function ver_variable($varia){
		if (CONFIG_MODO_DEPURACION){
			echo "<pre>";
			print_r($varia);
			echo "</pre>";
		}
}


//VALIDA COINCIDENCIA CON USUARIOS EXISTENTES DE LA UNED 
function verifica_usuarios_LDAP( $login, $password ) {
											
						 $servidor_LDAP = "ldap.uned.ac.cr";
						 $puerto=389;
						 $servidor_dominio = "uned.ac.cr";
						 $usuario_LDAP = $login;
						 $contrasena_LDAP = $password ;
						 $dn='dc=uned,dc=ac,dc=cr';
													  
						 $conectado_LDAP = ldap_connect($servidor_LDAP, $puerto) or false;
						 ldap_set_option($conectado_LDAP, LDAP_OPT_PROTOCOL_VERSION, 3);
						 ldap_set_option($conectado_LDAP, LDAP_OPT_REFERRALS, 0);
													 
						 $autenticado_LDAP = ldap_bind($conectado_LDAP, 
						 $usuario_LDAP . "@" . $servidor_dominio, $contrasena_LDAP) or false;
													  
						 if($autenticado_LDAP){
														  
									ldap_unbind($conectado_LDAP);	
									return true;					
						 }else{
														   
									ldap_unbind($conectado_LDAP);	
									return false;					
						}
											  
}


function is_valid_email($str)
{
  $matches = null;
  return (1 === preg_match('/^[A-z0-9\\._-]+@[A-z0-9][A-z0-9-]*(\\.[A-z0-9_-]+)*\\.([A-z]{2,6})$/', $str, $matches));
}

//Obtiene la IP del cliente
      function getRealIP(){

        if (isset($_SERVER["HTTP_CLIENT_IP"])){

            return $_SERVER["HTTP_CLIENT_IP"];

        }elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){

            return $_SERVER["HTTP_X_FORWARDED_FOR"];

        }elseif (isset($_SERVER["HTTP_X_FORWARDED"])){

            return $_SERVER["HTTP_X_FORWARDED"];

        }elseif (isset($_SERVER["HTTP_FORWARDED_FOR"])){

            return $_SERVER["HTTP_FORWARDED_FOR"];

        }elseif (isset($_SERVER["HTTP_FORWARDED"])){

            return $_SERVER["HTTP_FORWARDED"];

        }else{

            return $_SERVER["REMOTE_ADDR"];

        }
    }  


//FUNCION PARA ALEATORIOS
//1. Si retorna 0 ya no tiene opciones fuera del array para mostrar
//2. La cadena son las excepciones dentro del rago de numeros para mostrar
//3. Las variables menor y mayor son el tope del rago de numeros para mostrar
function random($menor, $mayor, $cadena) {
		if($cadena==''){
			$tamanno_cadena = 0;
		}else{
			$tamanno_cadena = count ( $cadena );
		}
	
	    if($tamanno_cadena >= $mayor){
			//LLEGO AL TOPE
			$random_number = 0;
			return $random_number;
		}else{
			$bandera_random=0;
			
			do{
			   $random_number = rand($menor,$mayor);
				if (in_array($random_number, $cadena)) {
					$bandera_random=0;
				}else{
					$bandera_random=1;
				}
	
			} while ($bandera_random==0);

			return $random_number;
		}
}


//FUNCION AGREGA VALOR A CADENA, SI ESTE NO EXISTE
function agrega_a_cadena($valor, $cadena) {
	if($cadena==''){
		$tamanno_cadena = 0;
	}else{
		$tamanno_cadena = count ( $cadena );
	}
	
	if (in_array($valor, $cadena)) {
		return $cadena;
	}else{
		$cadena[$tamanno_cadena] = $valor;
		return $cadena;
	}
}

//FUNCION AVERIGUAR SI NO EXISTE VALOR EN UNA CADENA
//1. true = el valor no existe en la cadena
//2. false = el valor si existe en la cadena
function no_existe_en_cadena($valor, $cadena) {
	if (in_array($valor, $cadena)) {
		return false;
	}else{
		return true;
	}
}

//FUNCION PARA COMENTARIO ALEATORIO
function comentario_dinamico(){
	$valor_aleatorio = random(1, 20, $_SESSION['cadena_comentarios']);
	if(valor_aleatorio == 0){ 
			unset($_SESSION['cadena_comentarios']); 
			$valor_aleatorio = random(1, 20, $_SESSION['cadena_comentarios']);
	}
	
	if($_SESSION['cadena_comentarios']==''){
       $var_cadena_comentarios = 0;
	}else{
	   $var_cadena_comentarios = count($_SESSION['cadena_comentarios']);
	}
	
	$contador = $var_cadena_comentarios - 1;
	$_SESSION['cadena_comentarios'][$contador] = $valor_aleatorio;
	
	switch ($valor_aleatorio) {
		case 1:
			$valor_retornado = 'Way to go! You are ready for the next level.';
			break;
		case 2:
			$valor_retornado = 'Amazing! You are ready for the next level.';
			break;
		case 3:
			$valor_retornado = 'You figured it out! You are ready for the next level.';
			break;
		case 4:
			$valor_retornado = 'Got it! You are ready for the next level.';
			break;
		case 5:
			$valor_retornado = 'That’s it! You are ready for the next level.';
			break;
		case 6:
			$valor_retornado = 'On fire! Let’s move to the next level.';
			break;
		case 7:
			$valor_retornado = 'Outstanding! Let’s move to the next level.';
			break;
		case 8:
			$valor_retornado = 'Good job! Let’s move to the next level.';
			break;
		case 9:
			$valor_retornado = 'You did it! Let’s move to the next level.';
			break;
		case 10:
			$valor_retornado = 'On the right track! Let’s move to the next level.';
			break;
		case 11:
			$valor_retornado = 'Congrats! Time for the next level.';
			break;
		case 12:
			$valor_retornado = 'Fantastic! Time for the next level.';
			break;
		case 13:
			$valor_retornado = 'Keep it up! Time for the next level.';
			break;
		case 14:
			$valor_retornado = 'Perfect! Time for the next level.';
			break;
		case 15:
			$valor_retornado = 'Figured it out! Time for the next level.';
			break;
		case 16:
			$valor_retornado = 'That’s the way! The next level is waiting for you.';
			break;
		case 17:
			$valor_retornado = 'Nice going! The next level is waiting for you.';
			break;
		case 18:
			$valor_retornado = 'Well played! The next level is waiting for you.';
			break;
		case 19:
			$valor_retornado = 'Impressive! The next level is waiting for you.';
			break;
		case 20:
			$valor_retornado = 'Hit the target! The next level is waiting for you.';
			break;
		default:
			$valor_retornado = 'Way to go! You are ready for the next level.';
	} 
	
	return $valor_retornado;

}



?>