<?php
 session_start();
 
 # Archivo de conexión
 require_once("lib/class_base.inc.php");

switch(basename($_SERVER['SCRIPT_NAME'])){

        case 'index.php':
             
            switch($_GET['action']){
                                                
    			//AQUI SE PUEDEN INTRODUCIR MAS CASOS

                default:
                                                                                                                                                    
                                                                    				            
                if (file_exists(CONFIG_PATH_INC_PUBLIC.$_GET['action'].".inc.php")) {                                     

                    include(CONFIG_PATH_INC_PUBLIC.$_GET['action'].".inc.php");            
                    exit;

                }else{ 
                                                                                                                    
                    include(CONFIG_PATH_INC_PUBLIC.'index.inc.php');
    				exit;
                }   
                break;

            } // switch
        break;
                                
        default:
        include(CONFIG_PATH_INC_PUBLIC.'index.inc.php');
		exit;
        break;
                                
} // switch
				
 ?>