<?php
$db = new BaseDatos();//Crea nueva conexión con la base de datos
if(@$db->conectar()){//Conecta base de datos

    //CONSULTA SI YA EXISTE LA IP
    /*
	$res_ip = @$db->consultaregistros("*", "jornada_2020"," `ip` LIKE '".getRealIP()."' ;", "2");

	if($res_ip == ''){
		$var_$res_ip = 0;
	}else{
		$var_$res_ip = count($res_ip);
	}

	if($var_$res_ip==0){
		  $insert_ip = @$db->insertaregistros("jornada_2020", "`id`, `ip`, `tuto`, `op_1`, `op_2`, `op_3`", "NULL, '".getRealIP()."', 'no', '', '', ''", "2"); 
		  $res_ip = @$db->consultaregistros("*", "jornada_2020"," `ip` LIKE '".getRealIP()."' ;", "2");
	}else{
		 $edita_registro = @$db->editaregistros("jornada_2020", "`tuto` = 'si'", "`ip` LIKE '".getRealIP()."' ", "2");
	}

	$variable_para_tuto = $res_ip[0][2];
	$total_vistas = @$db->cuentaregistros("jornada_2020", "2");

	*/

	//$res_ip2 = @$db->consultaregistros("*", "jornada_2020"," 1", "2");

	//$variable_para_tuto = 'no';
	//$total_vistas = 99000;



    @$db->desconectar();//desconecta la base de datos
		
}//if(@$db->conectar())/Conecta base de datos

include(CONFIG_PATH_TPL_PUBLIC."index.tpl.php")//LLAMA A LA PARTE HTML
?>