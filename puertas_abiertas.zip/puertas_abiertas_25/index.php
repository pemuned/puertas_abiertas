<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Galería virtual: Jornada de puertas abiertas y 25 aniversario</title>


<link rel="stylesheet" href="css/bootstrap.css">
<!-- letra -->
<link href="https://fonts.googleapis.com/css2?family=Manjari:wght@100;400;700&display=swap" rel="stylesheet">
<!-- Animaciones en CSS -->
<link rel="stylesheet" href="css/animations.css">
<!-- Carrusel -->
<link rel="stylesheet" href="css/flickity.css">
<!-- Estilos Propios -->
<link rel="stylesheet" href="css/estilos.css">
<!-- Carrusel en CSS -->
<link rel="stylesheet" href="css/carousel.css">
</head>

<body>

<div id="opaco_videos" align="center">
  <div id="ventana_video"><div id="contenido_ventana_video" align="center"></div><br><div class="boton_ventanas" onclick="javascript:abrir_ventana_video('0');">Cerrar</div></div>
</div>


<div id="opaco_compu" align="center"></div>
<div id="contenedor_ventana_compu" align="center"><div id="ventana_compu"><div id="contenido_ventana_compu" align="center"></div><br><div class="boton_ventanas" onclick="javascript:abrir_ventana_compu('0');">Cerrar</div></div></div>

<div id="opaco_movil" align="center"></div>
<div id="imagen_movil" align="center"></div>
<div id="contenedor_ventana_movil" align="center"><div id="ventana_movil">
  <div id="ventana_movil_contenido">
  </div>
  <br> 
  <div class="boton_ventanas" onclick="javascript:abrir_ventana_movil('0');">Cerrar</div>
</div></div>


<!-- 
<div id="opaco" align="center">
  
  <div class="slideDown" id="ventana_informacion" align="center">
    
        <div id="n_1">
          <div class="imagen_popup"><img src="images/popupinfo/galeria_ojo.svg"></div>
          <div class="texto_popup">Para navegar en la galería virtual puede hacerlo de 3 formas distintas:</div>
          <div class="tult_popup">
            <div class="circulo activo"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('1_2');"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('1_3');"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('1_4');"></div>
          </div>
          <div class="boton_ventanas" onclick="javascript:abrir_popup('2');">Siguiente</div>
        </div>
        <div id="n_2">
          <div class="imagen_popup"><img src="images/popupinfo/galeria_flechas_juntas.svg"></div>
          <div class="texto_popup">Con los botones de navegación de la interfaz</div>
          <div class="tult_popup">
            <div class="circulo" onclick="javascript:menu_bolitas('2_1');"></div>
            <div class="circulo activo"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('2_3');"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('2_4');"></div>
          </div>
          <div class="boton_ventanas" onclick="javascript:abrir_popup('3');">Siguiente</div>
        </div>
        <div id="n_3">
          <div class="imagen_popup" id="trespopup"><img src="images/popupinfo/galeria_mouse.svg"></div>
          <div class="texto_popup">Con la rueda de desplazamiento del ratón</div>
          <div class="tult_popup">
            <div class="circulo" onclick="javascript:menu_bolitas('3_1');"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('3_2');"></div>
            <div class="circulo activo"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('3_4');"></div>
          </div>
          <div class="boton_ventanas" onclick="javascript:abrir_popup('4');">Siguiente</div>
        </div>
        <div id="n_4">
          <div class="imagen_popup" id="cuatropopup"><img src="images/popupinfo/galeria_flechas_teclado.svg"></div>
          <div class="texto_popup">Con las flechas del teclado</div>
          <div class="tult_popup">
            <div class="circulo" onclick="javascript:menu_bolitas('4_1');"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('4_2');"></div>
            <div class="circulo" onclick="javascript:menu_bolitas('4_3');"></div>
            <div class="circulo activo"></div>
          </div>
          <div class="boton_ventanas" onclick="javascript:abrir_popup('0');">Entrar</div>
        </div>
  </div>

</div>
 -->

<div id="contenedor_dis_pequennos" align="center">
   <div id="contenedor_techo_movil"><div id="techo_movil"><div class="contenedor_luz_movil" align="center"><div class="luz_movil"><img src="images/elementos_moviles/luces.png"></div></div></div></div>
   <div class="espaciador"></div>
                    <div class="espaciador"></div>
  <div id="titulo_2"><p><b>Galería virtual</b></p></div>
                    <div id="titulo_moviles"><p>25 aniversario</p></div>
                     <div class="textos_moviles">
                       <p>Bienvenidas y bienvenidos a la galería virtual del Programa de Producción Electrónica Multimedial (PEM), de la Universidad Estatal a Distancia, de Costa Rica.jvjghv </p>
                       <div>
                       <div id="logo_multimedia"><img width="40" src="images/galeria_multimedia_logo.png"></div><div id="logo_uned"><img width="40" src="images/galeria_uned_logo.png"></div>
                       </div>
                        <div class="boton_afiche" onclick="javascript:abrir_ventana_movil('101');">Créditos</div>
                        <div class="espaciador"></div>
                    <div class="espaciador"></div><div class="espaciador"></div>
                    <div class="espaciador"></div><div class="espaciador"></div>
                    <div class="espaciador"></div>
</div></div>


<div id="contenedor_lobi" align="center">

     <div id="contenedor_techo_movil"><div id="techo_lobi">
      <div class="contenedor_luz_lobi" align="center"><div class="luz_lobi"><img src="images/elementos/luz3.png"></div></div>
    </div></div>
</div>


<div id="elementos_lobi">
<div id="pared"></div>
  <div id="rodapie"></div>
  <div id="piso" align="center"> 
      <div  id="contenido_lobi" align="center">
              <div class="col-lg-12">
                  <div class="col-lg-4" align="center">               
                    <div style="margin-top: 60px;"><img src="images/elementos/pensador_borrador.png"></div>
                  </div>
                  <div class="col-lg-4" align="center">
                    <div id="titulo_2"><p><b>Galería virtual</b></p></div>
                    <div id="titulo_moviles"><p>25 aniversario</p></div>
                     <div class="textos_moviles">
                       <p>Bienvenidas y bienvenidos a la galería virtual del Programa de Producción Electrónica Multimedial (PEM), de la Universidad Estatal a Distancia, de Costa Rica. </p>
                       <div style="width: 100%; height:80px;">
                        <div style="width: 50%; float: left; padding-right: 10px;" align="right"><img width="60" src="images/galeria_multimedia_logo.png"></div>
                        <div style="width: 50%; float: left; padding-left:10px;"><img width="40" src="images/galeria_uned_logo.png"></div>
                      </div>
                      <div style="width: 100%;" align="center">
                        <div class="boton_afiche" onclick="location.href='25_aniversario.php'" style="border-radius: 20px;">Entrar</div>
                        </div>
                      </div>
                  </div>
                  <div class="col-lg-4" align="center">
                    <div class="espaciador"></div><br>
                    <img width="100" src="images/elementos/cuadro_20_borrador.png"><br><br>
                    <a href="https://multimedia.uned.ac.cr/pem/puertas_abiertas/" target="_blank">20 Aniversario</a>
                    <div class="espaciador"></div>
                    <div id="cierre_movil"><img src="images/elementos/divisor.png"></div>
                  </div>
              </div>
      </div>
   
  </div>
</div>



</div>

<!-- 
<div id="flecha_derecha" onclick="javascript:avancer();"><img src="images/flecha der.svg"></div>
<div id="flecha_izquierda" onclick="javascript:retrocesor();"><img src="images/flecha izq_apa.svg"></div>
 -->

<div id="contenedor_creditos_fijos" align="center"><samp>©2020</samp> <a href="https://www.uned.ac.cr/" target="_blank">Universidad Estatal a Distancia</a> | <a id="ancla" onclick="javascript:abrir_creditos();" >Créditos</a></div>


<div id="creditos" align="center">

     <div id="cuerpo_creditos">
    
      <div id="abajo2"></div>
      <br>
      <div id="titulo_creditos"><b>Créditos</b></div>
      
      <div id="imagenescr">
         <div id="logo_multimedia"><img src="images/galeria_multimedia_logo.svg"></div><div id="logo_uned"><img src="images/galeria_uned_logo.svg"></div>
      </div>
       <div id="contenedor_linea"></div>

      <div align="left">
        <div id="titulo_moviles"><p><b>Galería virtual</b></p></div>
        <div id="titulo_2"><p>Jornada de puertas abiertas y 20 aniversario</p></div>
        <p><b>Código de publicación:</b> SW0120<br><b>Publicación:</b>1 diciembre 2020</p>
        <p>Esta galería es una producción de la Universidad Estatal a Distancia, Dirección de Producción de Materiales Didácticos y el Programa de Producción Electrónica Multimedial.</p>
        <p><b>Producción multimedia</b><br>Producción y diseño gráfico: Ana Carolina Zamora Sanabria, Juan Diego Delgado Vargas, Mario Badilla Quesada, Raquel Badilla Barrientos y Vivian González Zúñiga.<br>Desarrollo web: Romy Ulate Paniagua<br>Colaboración: Marco Antonio Sánchez Mora, Paúl Alvarado Quesada, Seidy Maroto Alfaro y Yuri Vázquez Pérez.<br>Agradecimientos: a todas las personas que colaboraron en la elaboración de esta Galería virtual.</p>
        <p><b>Derecho de Autor</b><br>ADVERTENCIA: Los derechos patrimoniales de la presente obra pertenecen en su totalidad a la Universidad Estatal a Distancia, de Costa Rica, por lo que está prohibida su copia o reproducción, comunicación pública, puesta a disposición del público, transmisión, transformación (incluyendo adaptación y traducción), distribución, alquiler o venta de ejemplares, realizada por cualquier medio o procedimiento, conocido o por conocerse, sin el consentimiento previo por escrito del titular de los derechos. Eludir esta prohibición o las medidas tecnológicas de protección que contenga la obra, constituye una conducta sancionada por normas de propiedad intelectual.</p>
        <br>
     </div>
     <div class="boton_ventanas" onclick="javascript:abrir_creditos();">Cerrar</div>

      </div>



</div>


<div id="contenedor_creditos_fijos_moviles" align="center">
  <div id="rodapie_movil"></div>
  <samp>©2020</samp> <a href="https://www.uned.ac.cr/" target="_blank">Universidad Estatal a Distancia</a> | <a id="ancla_movil" onclick="javascript:abrir_ventana_movil('101');" >Créditos</a></div>





<script src="js/jquery-1.11.3.min.js"></script> 
<script src="js/bootstrap.js"></script>
<script src="js/flickity.pkgd.min.js"></script>
<script src="js/funciones.js"></script>




</body>
</html>